import 'dart:ui';

class Constant{
  static const String widgetVersion = "3.0";
  static const Color scaffoldBackground = Color.fromARGB(240, 146, 20, 11) ;
}