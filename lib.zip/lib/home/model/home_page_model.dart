class Item {
  final String image;
  final String name;

  Item(this.image, this.name);
}
